package bitc.fullstack503.boardapiserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoardApiServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(BoardApiServerApplication.class, args);
    }

}
