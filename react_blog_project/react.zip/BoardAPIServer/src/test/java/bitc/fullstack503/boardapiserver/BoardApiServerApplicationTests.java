package bitc.fullstack503.boardapiserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoardApiServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
