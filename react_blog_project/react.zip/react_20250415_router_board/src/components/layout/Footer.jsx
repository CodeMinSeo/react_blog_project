function Footer() {
  return (
    <footer className="border-top border-2 p-5 mt-4">
      <p className={'lead text-muted text-center'}>made by fullstack503</p>

    </footer>
  );
}

export default Footer;