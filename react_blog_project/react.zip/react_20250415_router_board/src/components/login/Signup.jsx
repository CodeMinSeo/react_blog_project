function Signup() {
  return (
    <div>
      <h1>회원 가입 페이지</h1>
    </div>
  );
}

export default Signup;