import ProfilePage from './ProfilePage.jsx';

function Content() {
  return (
    <div>
      <ProfilePage />
    </div>
  );
}

export default Content;