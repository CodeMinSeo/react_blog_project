function Signup() {
  return (
    <div>
      <h1>Signup 페이지</h1>
      <p>Route 중첩을 사용하여 자식 Route 에서 index 속성을 사용하여 접속한 페이지</p>
    </div>
  );
}

export default Signup;