function Login() {
  return (
    <div>
      <h1>/page/Login 페이지 (절대 경로로 입력)</h1>
      <p>주소창에서 '서버주소/pages/login' 으로 입력해야 접속하는 페이지</p>
    </div>
  );
}

export default Login;