function Logout() {
  return (
    <div>
      <h1>Logout 페이지</h1>
      <p>Route 중첩을 사용 시 자식 Route 로 지정한 페이지</p>
    </div>
  );
}

export default Logout;