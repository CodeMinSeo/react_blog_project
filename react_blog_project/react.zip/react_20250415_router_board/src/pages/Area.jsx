function Area() {
  return (
    <div className={'border border-2 border-dark-subtle m-3 p-3'}>
      <h2>Outlet 을 사용하여 About 페이지에서 함께 포함될 페이지</h2>
      <p>Route 를 중첩으로 사용 시 부모 컴포넌트에서 자식 컴포넌트를 함께 출력할 때 사용</p>
    </div>
  );
}

export default Area;