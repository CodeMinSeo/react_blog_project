import Layout from './components/Layout.jsx';

function App() {

  return (
    <div className={'container mt-5'}>
      <Layout />
    </div>
  )
}

export default App
