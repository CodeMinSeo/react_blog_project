import React from "react";


const ThemeContext = React.createContext('dark');
ThemeContext.displayName = '테마_컨텍스트';

export default ThemeContext