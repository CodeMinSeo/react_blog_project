import Content from "./Content.jsx";

function Layout() {
    return (
        <Content />
    );
}

export default Layout